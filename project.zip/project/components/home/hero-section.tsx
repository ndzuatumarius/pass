"use client";

import { useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";

export function HeroSection() {
  const [searchQuery, setSearchQuery] = useState("");

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-primary/10 via-background to-background py-24">
      <div className="container relative z-10">
        <div className="mx-auto max-w-[800px] text-center">
          <h1 className="mb-6 text-4xl font-bold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl">
            Your Gateway to
            <span className="bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent"> Educational Excellence</span>
          </h1>
          <p className="mb-8 text-lg text-muted-foreground md:text-xl">
            Access thousands of high-quality educational resources. Perfect for students,
            teachers, and lifelong learners.
          </p>
          
          <div className="mx-auto mb-8 flex max-w-[600px] items-center gap-2 rounded-full border bg-background p-2">
            <Search className="ml-2 h-5 w-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search for resources..."
              className="border-0 bg-transparent focus-visible:ring-0"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Button size="sm" className="rounded-full">Search</Button>
          </div>

          <div className="flex flex-wrap justify-center gap-4">
            <Button size="lg" className="rounded-full" asChild>
              <Link href="/sections">Browse Resources</Link>
            </Button>
            <Button size="lg" variant="outline" className="rounded-full" asChild>
              <Link href="/about">Learn More</Link>
            </Button>
          </div>
        </div>
      </div>
      
      <div className="absolute inset-0 -z-10 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
    </section>
  );
}
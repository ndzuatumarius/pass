export function StatsSection() {
  return (
    <section className="border-y bg-muted/50">
      <div className="container py-12">
        <div className="grid grid-cols-2 gap-8 text-center md:grid-cols-4">
          {[
            { value: "10K+", label: "Resources" },
            { value: "50K+", label: "Students" },
            { value: "1K+", label: "Teachers" },
            { value: "95%", label: "Satisfaction" },
          ].map((stat) => (
            <div key={stat.label} className="space-y-2">
              <div className="text-3xl font-bold md:text-4xl">{stat.value}</div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
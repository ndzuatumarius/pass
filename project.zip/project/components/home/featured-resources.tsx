import { ResourceCard } from "./resource-card";
import { featuredResources } from "@/lib/constants/resources";
import type { Resource } from "@/lib/types/resource";

export function FeaturedResources() {
  return (
    <section className="container py-12">
      <h2 className="mb-8 text-3xl font-bold tracking-tight">Featured Resources</h2>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {featuredResources.map((resource: Resource) => (
          <ResourceCard key={resource.title} {...resource} />
        ))}
      </div>
    </section>
  );
}
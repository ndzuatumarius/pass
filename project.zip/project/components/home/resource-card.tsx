import { Button } from "@/components/ui/button";
import { Card, CardContent, CardTitle, CardDescription } from "@/components/ui/card";
import type { Resource } from "@/lib/types/resource";

type ResourceCardProps = Resource;

export function ResourceCard({ title, description, price }: ResourceCardProps) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="aspect-video w-full rounded-lg bg-muted" />
        <CardTitle className="mt-4">{title}</CardTitle>
        <CardDescription className="mt-2">{description}</CardDescription>
        <div className="mt-4 flex items-center justify-between">
          <span className="text-lg font-bold">${price.toFixed(2)}</span>
          <Button>View Details</Button>
        </div>
      </CardContent>
    </Card>
  );
}
import React from 'react';

interface SubjectProps {
  name: string;
  onClick: () => void;
}

const Subject: React.FC<SubjectProps> = ({ name, onClick }) => {
  return (
    <div
      className="bg-white p-4 rounded-lg shadow-md cursor-pointer hover:shadow-lg transition-shadow"
      onClick={onClick}
    >
      <h3 className="text-lg font-semibold">{name}</h3>
    </div>
  );
};

export default Subject;

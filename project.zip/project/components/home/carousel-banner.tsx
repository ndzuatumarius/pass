import React from 'react';
import Slider from 'react-slick'; // Import the slider component

const CarouselBanner: React.FC = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 1000,
    slidesToShow: 3,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 30000,
  };

  return (
    <div className="bg-gray-100 py-12">
      <div className="container mx-auto">
        <Slider {...settings}>
          {/* Card 1 */}
          <div className="card bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-bold mb-4">Multiple Systems</h3>
            <p className="text-gray-700 mb-4">
              Supporting both Anglophone and Francophone educational systems
              with specialized content for each
            </p>
            <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
              Choose System →
            </button>
          </div>

          {/* Card 2 */}
          <div className="card bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-bold mb-4">Past Questions Bank</h3>
            <p className="text-gray-700 mb-4">
              Access a comprehensive collection of past examination questions
              including multiple choice, essays, and practical exercises
            </p>
            <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
              Explore Questions →
            </button>
          </div>

          {/* Card 3 */}
          <div className="card bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-bold mb-4">Study Resources</h3>
            <p className="text-gray-700 mb-4">
              Get access to detailed solutions, study guides, and practice
              materials to help you prepare effectively
            </p>
            <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
              View Resources →
            </button>
          </div>
        </Slider>
      </div>
    </div>
  );
};

export default CarouselBanner;
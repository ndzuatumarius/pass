import React from 'react';

interface LevelProps {
  name: string;
  onClick: () => void;
}

const Level: React.FC<LevelProps> = ({ name, onClick }) => {
  return (
    <div
      className="bg-green-100 p-4 rounded-lg shadow-md cursor-pointer hover:shadow-lg transition-shadow"
      onClick={onClick}
    >
      <h3 className="text-lg font-semibold">{name}</h3>
    </div>
  );
};

export default Level;

import React from 'react';

interface CategoryProps {
  name: string;
  onClick: () => void;
}

const Category: React.FC<CategoryProps> = ({ name, onClick }) => {
  return (
    <div
      className="bg-white p-4 rounded-lg shadow-md cursor-pointer hover:shadow-lg transition-shadow"
      onClick={onClick}
    >
      <h3 className="text-lg font-semibold">{name}</h3>
    </div>
  );
};

export default Category;

import Image from "next/image";
import Link from "next/link";
import { Card, CardContent } from "@/components/ui/card";
import { useEffect, useState } from "react";

// Define the Material type
interface Material {
  id: number; // or string based on your data
  slug: string;
  image: string;
  title: string;
  resourceCount: number;
}

// Define a static placeholder image using the public path
const PLACEHOLDER_IMAGE = "/images/placeholder2.jpg"; // Public path for the placeholder image

export function SubjectsSection() {
  const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;
  const [materials, setSubjectMaterials] = useState<Material[]>([]); // Use the Material type

  useEffect(() => {
    const fetchSubjectMaterials = async () => {
      try {
        const materialsResponse = await fetch(`${apiBaseUrl}/api/materials`);
        const materialsData: Material[] = await materialsResponse.json();
        console.log(materialsData); // Log the data to check the response
        setSubjectMaterials(materialsData);
        

      } catch (error) {
        console.error('Error fetching materials:', error);
      }
    };

    fetchSubjectMaterials();
  }, []);

  return (
    <section className="container py-12">
      <div className="mb-8 text-center">
        <h2 className="mb-2 text-3xl font-bold tracking-tight">Popular Materials</h2>
        <p className="text-muted-foreground">
          Explore our wide range of materials and find the perfect resources for your needs
        </p>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {materials.map((material) => (
  <Link key={material.id} href={`/materials/${material.slug}`}>
    <Card className="group overflow-hidden">
      <CardContent className="p-0">
        <div className="aspect-[4/3] relative overflow-hidden">
          <Image
            src={material.image || PLACEHOLDER_IMAGE}
            alt={material.title || "Placeholder Image"}
            fill
            className="object-cover transition-transform duration-300 group-hover:scale-105"
            priority // Added priority for LCP optimization
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-4 left-4 right-4">
            <h3 className="text-xl font-semibold text-white">{material.title}</h3>
            <p className="text-sm text-white/80">{material.resourceCount} materials</p>
          </div>
        </div>
      </CardContent>
    </Card>
  </Link>
))}
      </div>
    </section>
  );
}
import React from 'react';

interface SectionProps {
  name: string;
  description?: string;
  onClick: () => void;
}

const Section: React.FC<SectionProps> = ({ name, description, onClick }) => {
  return (
    <div
      className="bg-white p-4 rounded-lg shadow-md cursor-pointer hover:shadow-lg transition-shadow"
      onClick={onClick}
    >
      <h3 className="text-lg font-semibold">{name}</h3>
      {description && <p className="text-gray-600 mt-2">{description}</p>}
    </div>
  );
};

export default Section;

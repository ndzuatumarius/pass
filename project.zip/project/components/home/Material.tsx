import React from 'react';

interface MaterialProps {
  name: string;
  previewUrl: string;
  onPurchase: () => void;
}

const Material: React.FC<MaterialProps> = ({ name, previewUrl, onPurchase }) => {
  return (
    <div className="bg-white p-4 rounded-lg shadow-md">
      <h3 className="text-lg font-semibold">{name}</h3>
      <img src={previewUrl} alt={name} className="mt-2 w-full max-h-48 object-contain" />
      <button
        className="mt-4 bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded"
        onClick={onPurchase}
      >
        Purchase
      </button>
    </div>
  );
};

export default Material;

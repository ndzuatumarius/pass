import { BookOpen, GraduationCap, Users, BookCheck } from "lucide-react";
import { FeatureCard } from "./feature-card";

const features = [
  {
    icon: BookOpen,
    title: "Extensive Library",
    description: "Access thousands of educational resources across multiple subjects",
  },
  {
    icon: GraduationCap,
    title: "Expert-Curated",
    description: "Materials vetted and created by education professionals",
  },
  {
    icon: Users,
    title: "Multi-Level Support",
    description: "Resources for all learning levels from elementary to advanced",
  },
  {
    icon: BookCheck,
    title: "Quality Assured",
    description: "Regularly updated content meeting educational standards",
  },
];

export function FeaturesSection() {
  return (
    <section className="container py-12">
      <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
        {features.map((feature) => (
          <FeatureCard key={feature.title} {...feature} />
        ))}
      </div>
    </section>
  );
}
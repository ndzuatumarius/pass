"use client";

import { createContext, useContext } from "react";

interface AdminContextType {
  user: {
    email: string;
  };
}

const AdminContext = createContext<AdminContextType>({
  user: {
    email: "pass@edu.cm",
  },
});

export function AdminProvider({ children }: { children: React.ReactNode }) {
  return (
    <AdminContext.Provider
      value={{
        user: {
          email: "pass@edu.cm",
        },
      }}
    >
      {children}
    </AdminContext.Provider>
  );
}

export const useAdmin = () => useContext(AdminContext);
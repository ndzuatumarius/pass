import { BookOpen } from "lucide-react";

export function FooterBrand() {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center gap-2">
        <BookOpen className="h-6 w-6" />
        <span className="text-xl font-bold">PASS</span>
      </div>
      <p className="text-sm text-muted-foreground">
        Premium educational resources for all learning levels
      </p>
    </div>
  );
}
import { FooterBrand } from "./footer-brand";
import { FooterSection } from "./footer-section";
import { footerLinks } from "@/lib/constants/navigation";

export function Footer() {
  return (
    <footer className="border-t bg-background">
      <div className="container py-8 md:py-12">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
          <FooterBrand />
          <FooterSection title="Resources" links={footerLinks.resources} />
          <FooterSection title="Company" links={footerLinks.company} />
          <FooterSection title="Legal" links={footerLinks.legal} />
        </div>
        
        <div className="mt-8 border-t pt-8 text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} PASS. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
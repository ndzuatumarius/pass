import Link from "next/link";
import { NavigationMenu, NavigationMenuItem, NavigationMenuList } from "@/components/ui/navigation-menu";
import { navigationLinks } from "@/lib/constants/navigation";

export function NavItems() {
  return (
    <NavigationMenu>
      <NavigationMenuList className="hidden md:flex">
        {navigationLinks.map((link) => (
          <NavigationMenuItem key={link.href}>
            <Link href={link.href} className="px-4 py-2">
              {link.label}
            </Link>
          </NavigationMenuItem>
        ))}
      </NavigationMenuList>
    </NavigationMenu>
  );
}
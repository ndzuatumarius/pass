import Link from "next/link";
import { BookOpen } from "lucide-react";

export function Logo() {
  return (
    <div className="flex items-center gap-2">
      <BookOpen className="h-6 w-6" />
      <Link href="/" className="text-xl font-bold">
        PASS
      </Link>
    </div>
  );
}
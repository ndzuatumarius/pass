"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cn } from "@/lib/utils";
import { 
  LayoutDashboard, 
  Layers, 
  BookOpen, 
  GraduationCap,
  ShoppingCart,
  Receipt,
  CreditCard,
  Users,
  Settings
} from "lucide-react";

const sidebarItems = [
  { icon: LayoutDashboard, label: "Dashboard", href: "/admin" },
  { icon: Layers, label: "Sections", href: "/admin/sections" },
  { icon: BookOpen, label: "Levels", href: "/admin/levels" },
  { icon: GraduationCap, label: "Categories", href: "/admin/categories" },
  { icon: BookOpen, label: "Subjects", href: "/admin/subjects" },
  { icon: ShoppingCart, label: "Orders", href: "/admin/orders" },
  { icon: Receipt, label: "Transactions", href: "/admin/transactions" },
  { icon: CreditCard, label: "Payments", href: "/admin/payments" },
  { icon: Users, label: "Users", href: "/admin/users" },
  { icon: Settings, label: "Settings", href: "/admin/settings" },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <div className="w-64 min-h-screen border-r bg-background">
      <div className="p-6">
        <div className="flex items-center gap-2 mb-6">
          <BookOpen className="h-6 w-6" />
          <span className="font-bold">PASS Admin</span>
        </div>
        <nav className="space-y-1">
          {sidebarItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors",
                pathname === item.href
                  ? "bg-primary/10 text-primary"
                  : "hover:bg-muted"
              )}
            >
              <item.icon className="h-4 w-4" />
              {item.label}
            </Link>
          ))}
        </nav>
      </div>
    </div>
  );
}
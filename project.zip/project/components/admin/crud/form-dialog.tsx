"use client";

import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form } from "@/components/ui/form";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { FormFieldInput } from "./form-field";
import { getFieldLabel } from "@/lib/utils/form";

interface FormDialogProps {
  open: boolean;
  onClose: () => void;
  title: string;
  schema: any;
  defaultValues?: any;
  onSubmit: (data: any) => Promise<void>;
  isSubmitting?: boolean;
}

export function FormDialog({
  open,
  onClose,
  title,
  schema,
  defaultValues,
  onSubmit,
  isSubmitting,
}: FormDialogProps) {
  const form = useForm({
    resolver: zodResolver(schema),
    defaultValues: defaultValues || {},
  });

  const fields = Object.keys(schema.shape);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            {fields.map((fieldName) => (
              <FormFieldInput
                key={fieldName}
                name={fieldName}
                label={getFieldLabel(fieldName)}
                control={form.control}
              />
            ))}
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting && (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                )}
                Save
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
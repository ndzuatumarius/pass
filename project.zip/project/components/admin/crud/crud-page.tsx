import { useState, useCallback } from "react";
import { DataTable } from "./data-table";
import { FormDialog } from "./form-dialog";
import { useCrud } from "@/lib/hooks/use-crud";

interface CrudPageProps {
  title: string;
  columns: { key: string; label: string }[];
  schema: any;
  endpoint: string;
  queryKey: string;
}

export function CrudPage({
  title,
  columns,
  schema,
  endpoint,
  queryKey,
}: CrudPageProps) {
  const [open, setOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<any>(null);

  const { data, isLoading, create, isCreating, update, isUpdating, remove } = useCrud({
    endpoint,
    queryKey,
  });

  const handleAdd = useCallback(() => {
    setEditingItem(null);
    setOpen(true);
  }, []);

  const handleEdit = useCallback((item: any) => {
    setEditingItem(item);
    setOpen(true);
  }, []);

  const handleClose = useCallback(() => {
    setOpen(false);
    setEditingItem(null);
  }, []);

  const handleSubmit = useCallback(async (formData: any) => {
    if (editingItem) {
      await update({ id: editingItem.id, data: formData });
    } else {
      await create(formData);
    }
    handleClose();
  }, [editingItem, update, create, handleClose]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">{title}</h1>
      </div>

      <DataTable
        columns={columns}
        data={data}
        isLoading={isLoading}
        onAdd={handleAdd}
        onEdit={handleEdit}
        onDelete={remove}
      />

      <FormDialog
        open={open}
        onClose={handleClose}
        title={editingItem ? `Edit ${title}` : `Add ${title}`}
        schema={schema}
        defaultValues={editingItem}
        onSubmit={handleSubmit}
        isSubmitting={isCreating || isUpdating}
      />
    </div>
  );
}
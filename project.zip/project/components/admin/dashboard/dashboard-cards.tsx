import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Layers, 
  Upload,
  Users,
  BookOpen,
  ShoppingCart,
  BarChart
} from "lucide-react";

const cards = [
  {
    title: "Sections Management",
    description: "Manage educational sections, levels, and subjects",
    icon: Layers,
    action: "Manage Sections",
    href: "/admin/sections"
  },
  {
    title: "Material Management",
    description: "Upload and manage examination papers and solutions",
    icon: Upload,
    action: "Manage Content",
    href: "/admin/content"
  },
  {
    title: "User Management",
    description: "Manage user roles and permissions",
    icon: Users,
    action: "Manage Users",
    href: "/admin/users"
  },
  {
    title: "Levels",
    description: "Manage educational levels and categories",
    icon: BookOpen,
    action: "Manage Levels",
    href: "/admin/levels"
  },
  {
    title: "Orders",
    description: "View and manage platform orders",
    icon: ShoppingCart,
    action: "Manage Orders",
    href: "/admin/orders"
  },
  {
    title: "Analytics",
    description: "View platform usage statistics and reports",
    icon: BarChart,
    action: "View Analytics",
    href: "/admin/analytics"
  }
];

export function DashboardCards() {
  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {cards.map((card) => (
        <Card key={card.title}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <card.icon className="h-5 w-5" />
              {card.title}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground mb-4">
              {card.description}
            </p>
            <Button asChild>
              <Link href={card.href}>{card.action}</Link>
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

export function Header() {
  return (
    <header className="border-b">
      <div className="flex h-16 items-center px-6">
        <div className="flex flex-1 items-center gap-4">
   
        </div>
      
      </div>
    </header>
  );
}
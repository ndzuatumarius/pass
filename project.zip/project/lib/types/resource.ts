export interface Resource {
  id?: string;
  title: string;
  description: string;
  price: number;
  category?: string;
  level?: string;
  author?: string;
  rating?: number;
  reviews?: number;
  createdAt?: Date;
  updatedAt?: Date;
}

export interface Section {
  id: string;
  name: string;
  description?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Level {
  id: string;
  name: string;
  description?: string;
  sectionId: string;
  createdAt: string;
  updatedAt: string;
}

export interface Category {
  id: string;
  name: string;
  description?: string;
  levelId: string;
  createdAt: string;
  updatedAt: string;
}

export interface Subject {
  id: string;
  name: string;
  description?: string;
  categoryId: string;
  createdAt: string;
  updatedAt: string;
}

export interface Material {
  id: string;
  title: string;
  description?: string;
  fileUrl: string;
  price: number;
  subjectId: string;
  createdAt: string;
  updatedAt: string;
}

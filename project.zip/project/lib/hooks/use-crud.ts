import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";

interface UseCrudOptions {
  endpoint: string;
  queryKey: string;
}
const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;

  // Example of making an API request
  const fetchData = async () => {
    const response = await fetch(`${apiBaseUrl}/api/sections`);
    const data = await response.json();
    console.log(data);
  };
export function useCrud({ endpoint, queryKey }: UseCrudOptions) {
  const queryClient = useQueryClient();

  const { data, isLoading } = useQuery({
    queryKey: [queryKey],
    queryFn: () => fetch(`${apiBaseUrl}/api/${endpoint}`).then((res) => res.json()),
  });

  const { mutate: create, isPending: isCreating } = useMutation({
    mutationFn: (data: any) =>
      fetch(`${apiBaseUrl}/api/${endpoint}`, {
        method: "POST",
        body: JSON.stringify(data),
      }).then((res) => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryKey] });
      toast.success("Item created successfully");
    },
    onError: () => {
      toast.error("Failed to create item");
    },
  });

  const { mutate: update, isPending: isUpdating } = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) =>
      fetch(`${apiBaseUrl}/api/${endpoint}/${id}`, {
        method: "PUT",
        body: JSON.stringify(data),
      }).then((res) => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryKey] });
      toast.success("Item updated successfully");
    },
    onError: () => {
      toast.error("Failed to update item");
    },
  });

  const { mutate: remove, isPending: isDeleting } = useMutation({
    mutationFn: (id: string) =>
      fetch(`${apiBaseUrl}/api/${endpoint}/${id}`, {
        method: "DELETE",
      }).then((res) => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [queryKey] });
      toast.success("Item deleted successfully");
    },
    onError: () => {
      toast.error("Failed to delete item");
    },
  });

  return {
    data,
    isLoading,
    create,
    isCreating,
    update,
    isUpdating,
    remove,
    isDeleting,
  };
}
export const subjects = [
  {
    name: "Mathematics",
    slug: "mathematics",
    image: "https://images.unsplash.com/photo-1509228468518-180dd4864904?w=800&auto=format&fit=crop&q=60",
    resourceCount: 234,
  },
  {
    name: "Physics",
    slug: "physics",
    image: "https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=800&auto=format&fit=crop&q=60",
    resourceCount: 156,
  },
  {
    name: "Chemistry",
    slug: "chemistry",
    image: "https://images.unsplash.com/photo-1603126857599-f6e157fa2fe6?w=800&auto=format&fit=crop&q=60",
    resourceCount: 189,
  },
  {
    name: "Biology",
    slug: "biology",
    image: "https://images.unsplash.com/photo-1576086213369-97a306d36557?w=800&auto=format&fit=crop&q=60",
    resourceCount: 167,
  },
  {
    name: "English",
    slug: "english",
    image: "https://images.unsplash.com/photo-1457369804613-52c61a468e7d?w=800&auto=format&fit=crop&q=60",
    resourceCount: 245,
  },
  {
    name: "History",
    slug: "history",
    image: "https://images.unsplash.com/photo-1461360370896-922624d12aa1?w=800&auto=format&fit=crop&q=60",
    resourceCount: 178,
  },
] as const;
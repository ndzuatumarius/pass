export const footerLinks = {
  resources: [
    { href: "/sections", label: "Browse All" },
    { href: "/new", label: "Latest Resources" },
    { href: "/featured", label: "Featured Content" },
  ],
  company: [
    { href: "/about", label: "About Us" },
    { href: "/contact", label: "Contact" },
    { href: "/careers", label: "Careers" },
  ],
  legal: [
    { href: "/privacy", label: "Privacy Policy" },
    { href: "/terms", label: "Terms of Service" },
  ],
};

export const navigationLinks = [
  { href: "/sections", label: "Sections" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
];
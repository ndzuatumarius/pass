export const featuredResources = [
  {
    title: "Mathematics Fundamentals",
    description: "Comprehensive guide covering essential math concepts for grades 6-8",
    price: 29.99,
  },
  {
    title: "Science Lab Experiments",
    description: "Collection of hands-on science experiments for middle school",
    price: 34.99,
  },
  {
    title: "English Writing Skills",
    description: "Advanced writing techniques and exercises for high school students",
    price: 24.99,
  },
] as const;

export const resourceCategories = [
  "Mathematics",
  "Science",
  "English",
  "History",
  "Languages",
  "Arts",
] as const;

export type ResourceCategory = typeof resourceCategories[number];
import { z } from "zod";

export const baseSchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().optional(),
});

export const sectionSchema = baseSchema;

export const levelSchema = baseSchema.extend({
  sectionId: z.string().min(1, "Section is required"),
});

export const categorySchema = baseSchema.extend({
  levelId: z.string().min(1, "Level is required"),
});

export const subjectSchema = baseSchema.extend({
  categoryId: z.string().min(1, "Category is required"),
});

export const materialSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  price: z.number().min(0, "Price must be positive"),
  subjectId: z.string().min(1, "Subject is required"),
  fileUrl: z.string().min(1, "File URL is required"), // Make fileUrl required
});

export const orderSchema = z.object({
  materialId: z.string().min(1, "Material is required"),
  userId: z.string().min(1, "User is required"),
  status: z.enum(["pending", "completed", "refunded", "disputed"]),
  amount: z.number().min(0, "Amount must be positive"),
});

export const transactionSchema = z.object({
  orderId: z.string().min(1, "Order is required"),
  type: z.enum(["payment", "refund"]),
  status: z.enum(["success", "failed", "pending"]),
  amount: z.number().min(0, "Amount must be positive"),
  paymentMethod: z.string().min(1, "Payment method is required"),
});

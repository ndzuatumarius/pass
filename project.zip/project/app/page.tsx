'use client'
import { useState, useEffect } from "react";
import { Section, Level, Category, Subject, Material } from '@/lib/types/resource';
import SectionComponent from "components/home/Section";
import LevelComponent from "components/home/Level";
import CategoryComponent from "components/home/Category";
import SubjectComponent from "components/home/Subject";
import MaterialComponent from "components/home/Material";
import React from 'react';
import CarouselBanner from '../components/home/carousel-banner';

import { StatsSection } from "@/components/home/stats-section";
import { SubjectsSection } from "@/components/home/subjects-section";

import { FeaturedResources } from "@/components/home/featured-resources";

interface SectionData {
  id: string;
  name: string;
  description?: string;
  levels: Level[];
}

interface LevelData {
  id: string;
  name: string;
  sectionId: string;
  createdAt: Date;
  updatedAt: Date;
  categories: Category[];
}

interface CategoryData {
  id: string;
  name: string;
  levelId: string;
  subjects: Subject[];
}

interface SubjectData {
  id: string;
  name: string;
  categoryId: string;
  materials: Material[];
}

interface MaterialData {
  id: string;
  title: string;
  description?: string;
  fileUrl: string;
  price: number;
  subjectId: string;
}

enum NavigationLevel {
  SECTIONS,
  LEVELS,
  CATEGORIES,
  SUBJECTS,
  MATERIALS,
}

export default function Home() {
  const [sections, setSections] = useState<Section[]>([]);
  const [levels, setLevels] = useState<LevelData[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [materials, setMaterials] = useState<Material[]>([]);

  const [currentSection, setCurrentSection] = useState<Section | null>(null);
  const [currentLevel, setCurrentLevel] = useState<LevelData | null>(null);
  const [currentCategory, setCurrentCategory] = useState<Category | null>(null);
  const [currentSubject, setCurrentSubject] = useState<Subject | null>(null);
  const [navigation, setNavigation] = useState<NavigationLevel>(NavigationLevel.SECTIONS);
  const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;

  // Example of making an API request
  const fetchData = async () => {
    const response = await fetch(`${apiBaseUrl}/api/sections`);
    const data = await response.json();
    console.log(data);
  };
  

  useEffect(() => {
    const fetchData = async () => {
      try {
        const sectionsResponse = await fetch(`${apiBaseUrl}/api/sections`);
        const sectionsData: Section[] = await sectionsResponse.json();
        setSections(sectionsData);

        const levelsResponse = await fetch(`${apiBaseUrl}/api/levels`);
        const levelsData: LevelData[] = await levelsResponse.json();
        setLevels(levelsData);

        const categoriesResponse = await fetch(`${apiBaseUrl}/api/categories`);
        const categoriesData: Category[] = await categoriesResponse.json();
        setCategories(categoriesData);

        const subjectsResponse = await fetch(`${apiBaseUrl}/api/subjects`);
        const subjectsData: Subject[] = await subjectsResponse.json();
        setSubjects(subjectsData);

        const materialsResponse = await fetch(`${apiBaseUrl}/api/materials`);
        const materialsData: Material[] = await materialsResponse.json();
        setMaterials(materialsData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  const handleSectionClick = (section: Section) => {
    setCurrentSection(section);
    setNavigation(NavigationLevel.LEVELS);
  };

  const handleLevelClick = (level: LevelData) => {
    setCurrentLevel(level);
    setNavigation(NavigationLevel.CATEGORIES);
  };

  const handleCategoryClick = (category: Category) => {
    setCurrentCategory(category);
    setNavigation(NavigationLevel.SUBJECTS);
  };

  const handleSubjectClick = (subject: Subject) => {
    setCurrentSubject(subject);
    setNavigation(NavigationLevel.MATERIALS);
  };

  const handleGoBack = () => {
    if (navigation === NavigationLevel.MATERIALS) {
      setNavigation(NavigationLevel.SUBJECTS);
      setCurrentSubject(null);
    } else if (navigation === NavigationLevel.SUBJECTS) {
      setNavigation(NavigationLevel.CATEGORIES);
      setCurrentCategory(null);
    } else if (navigation === NavigationLevel.CATEGORIES) {
      setNavigation(NavigationLevel.LEVELS);
      setCurrentLevel(null);
    } else if (navigation === NavigationLevel.LEVELS) {
      setNavigation(NavigationLevel.SECTIONS);
      setCurrentSection(null);
    }
  };

  const handlePurchase = () => {
    // Implement Flutterwave integration here
    console.log("Purchase initiated");
  };

  return (
    <div className="p-4">
      <CarouselBanner />

      {navigation !== NavigationLevel.SECTIONS && (
        <button
          className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-bold py-2 px-4 rounded mb-4"
          onClick={handleGoBack}
        >
          Back
        </button>
      )}

      {navigation === NavigationLevel.SECTIONS && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {sections.map((section) => (
            <div className="gradient-card">
              <SectionComponent
                key={section.id}
                name={section.name}
                description={section.description}
                onClick={() => handleSectionClick(section)}
              />
            </div>
          ))}
        </div>
      )}

      {navigation === NavigationLevel.LEVELS && currentSection && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {levels
            .filter((level) => level.sectionId === currentSection.id)
            .map((level) => (
              <div className="gradient-card">
                <LevelComponent
                  key={level.id}
                  name={level.name}
                  onClick={() => handleLevelClick(level)}
                />
              </div>
            ))}
        </div>
      )}

{navigation === NavigationLevel.CATEGORIES && currentLevel && (
  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
    {categories
      .filter((category) => category.levelId === currentLevel.id)
      .map((category) => (
        <div className="gradient-card">
          <CategoryComponent
            key={category.id}
            name={category.name}
            onClick={() => handleCategoryClick(category)}
          />
        </div>
      ))}
  </div>
)}
      {navigation === NavigationLevel.SUBJECTS && currentCategory && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {subjects
            .filter((subject) => subject.categoryId === currentCategory.id)
            .map((subject) => (
              <div className="gradient-card">
                <SubjectComponent
                  key={subject.id}
                  name={subject.name}
                  onClick={() => handleSubjectClick(subject)}
                />
              </div>
            ))}
        </div>
      )}

      {navigation === NavigationLevel.MATERIALS && currentSubject && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {materials
            .filter((material) => material.subjectId === currentSubject.id)
            .map((material) => (
              <div className="gradient-card">
                <MaterialComponent
                  key={material.id}
                  name={material.title}
                  previewUrl={material.fileUrl}
                  onPurchase={handlePurchase}
                />
              </div>
            ))}
        </div>
      )}
  
    <StatsSection />
    <SubjectsSection />
   
    <FeaturedResources />

    </div>
  );
}

import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { levelSchema } from "@/lib/validations/form";
import { z, ZodError } from "zod";

export async function GET() {
  try {
    const levels = await prisma.level.findMany({
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json(levels);
  } catch (error) {
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();

    // Validate that the request payload is not empty
    if (Object.keys(body).length === 0) {
      return NextResponse.json(
        { error: "Request payload is empty" },
        { status: 400 }
      );
    }

    // Validate the request payload using the Zod schema
    const validatedData = levelSchema.parse(body);

    const level = await prisma.level.create({
      data: validatedData,
    });

    return NextResponse.json(level);
  } catch (error) {
    if (error instanceof ZodError) {
      return NextResponse.json(
        { error: "Invalid request data", issues: error.errors },
        { status: 400 }
      );
    } else {
      return NextResponse.json(
        { error: "Internal Server Error" },
        { status: 500 }
      );
    }
  }
}

export async function PUT(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "ID is required" }, { status: 400 });
    }

    const body = await req.json();
    const updateData = levelSchema.parse(body);

    const updatedLevel = await prisma.level.update({
      where: { id: id },
      data: updateData,
    });

    return NextResponse.json(updatedLevel);
  } catch (error) {
    if (error instanceof ZodError) {
      return NextResponse.json(
        { error: "Invalid request data", issues: error.errors },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "ID is required" }, { status: 400 });
    }

    await prisma.level.delete({
      where: { id },
    });

    return NextResponse.json({ message: "Level deleted successfully" });
  } catch (error) {
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}

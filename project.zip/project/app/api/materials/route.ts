import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { materialSchema } from "@/lib/validations/form";
import { z, ZodError } from "zod";

export async function GET() {
  try {
    const materials = await prisma.material.findMany({
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json(materials);
  } catch (error) {
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();

    // Validate that the request payload is not empty
    if (Object.keys(body).length === 0) {
      return NextResponse.json(
        { error: "Request payload is empty" },
        { status: 400 }
      );
    }

    // Validate the request payload using the Zod schema
    const validatedData = materialSchema.parse(body);

    // Temporarily add a placeholder fileUrl
    const material = await prisma.material.create({
      data: {
        ...validatedData,
        fileUrl: "placeholder-url", // Replace with actual file URL in a real implementation
      },
    });

    return NextResponse.json(material);
  } catch (error) {
    if (error instanceof ZodError) {
      return NextResponse.json(
        { error: "Invalid request data", issues: error.errors },
        { status: 400 }
      );
    } else {
      return NextResponse.json(
        { error: "Internal Server Error" },
        { status: 500 }
      );
    }
  }
}

export async function PUT(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "ID is required" }, { status: 400 });
    }

    const body = await req.json();
    const updateData = materialSchema.parse(body);

    const updatedMaterial = await prisma.material.update({
      where: { id: id },
      data: updateData,
    });

    return NextResponse.json(updatedMaterial);
  } catch (error) {
    if (error instanceof ZodError) {
      return NextResponse.json(
        { error: "Invalid request data", issues: error.errors },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "ID is required" }, { status: 400 });
    }

    await prisma.material.delete({
      where: { id },
    });

    return NextResponse.json({ message: "Material deleted successfully" });
  } catch (error) {
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}

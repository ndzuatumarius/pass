import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { subjectSchema } from "@/lib/validations/form";
import { z, ZodError } from "zod";

export async function GET() {
  try {
    const subjects = await prisma.subject.findMany({
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json(subjects);
  } catch (error) {
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();

    // Validate that the request payload is not empty
    if (Object.keys(body).length === 0) {
      return NextResponse.json(
        { error: "Request payload is empty" },
        { status: 400 }
      );
    }

    // Validate the request payload using the Zod schema
    const validatedData = subjectSchema.parse(body);

    const subject = await prisma.subject.create({
      data: validatedData,
    });

    return NextResponse.json(subject);
  } catch (error) {
    if (error instanceof ZodError) {
      return NextResponse.json(
        { error: "Invalid request data", issues: error.errors },
        { status: 400 }
      );
    } else {
      return NextResponse.json(
        { error: "Internal Server Error" },
        { status: 500 }
      );
    }
  }
}

export async function PUT(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "ID is required" }, { status: 400 });
    }

    const body = await req.json();
    const updateData = subjectSchema.parse(body);

    const updatedSubject = await prisma.subject.update({
      where: { id: id },
      data: updateData,
    });

    return NextResponse.json(updatedSubject);
  } catch (error) {
    if (error instanceof ZodError) {
      return NextResponse.json(
        { error: "Invalid request data", issues: error.errors },
        { status: 400 }
      );
    }
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json({ error: "ID is required" }, { status: 400 });
    }

    await prisma.subject.delete({
      where: { id },
    });

    return NextResponse.json({ message: "Subject deleted successfully" });
  } catch (error) {
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}

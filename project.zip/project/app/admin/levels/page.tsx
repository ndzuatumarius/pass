"use client";

import { CrudPage } from "@/components/admin/crud/crud-page";
import { levelSchema } from "@/lib/validations/form";

const columns = [
  { key: "name", label: "Name" },
  { key: "description", label: "Description" },
  { key: "sectionId", label: "Section" },
];

export default function LevelsPage() {
  return (
    <CrudPage
      title="Levels"
      columns={columns}
      schema={levelSchema}
      endpoint="levels"
      queryKey="levels"
    />
  );
}
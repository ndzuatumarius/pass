"use client";

import { CrudPage } from "@/components/admin/crud/crud-page";
import { sectionSchema } from "@/lib/validations/form";

const columns = [
  { key: "name", label: "Name" },
  { key: "description", label: "Description" },
];

export default function SectionsPage() {
  return (
    <CrudPage
      title="Sections"
      columns={columns}
      schema={sectionSchema}
      endpoint="sections"
      queryKey="sections"
    />
  );
}
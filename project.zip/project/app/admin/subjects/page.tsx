"use client";

import { CrudPage } from "@/components/admin/crud/crud-page";
import { subjectSchema } from "@/lib/validations/form";

const columns = [
  { key: "name", label: "Name" },
  { key: "description", label: "Description" },
  { key: "categoryId", label: "Category" },
];

export default function SubjectsPage() {
  return (
    <CrudPage
      title="Subjects"
      columns={columns}
      schema={subjectSchema}
      endpoint="subjects"
      queryKey="subjects"
    />
  );
}
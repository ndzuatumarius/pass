"use client";

import { CrudPage } from "@/components/admin/crud/crud-page";
import { orderSchema } from "@/lib/validations/form";

const columns = [
  { key: "materialId", label: "Material" },
  { key: "userId", label: "User" },
  { key: "status", label: "Status" },
  { key: "amount", label: "Amount" },
  { key: "createdAt", label: "Created At" },
];

export default function OrdersPage() {
  return (
    <CrudPage
      title="Orders"
      columns={columns}
      schema={orderSchema}
      endpoint="orders"
      queryKey="orders"
    />
  );
}
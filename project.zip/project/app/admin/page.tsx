"use client";

import { useAdmin } from "@/components/providers/admin-provider";
import { DashboardCards } from "@/components/admin/dashboard/dashboard-cards";

export default function AdminDashboard() {
  const { user } = useAdmin();
  
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Welcome, {user.email}</h1>
      <DashboardCards />
    </div>
  );
}
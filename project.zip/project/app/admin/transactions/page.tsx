"use client";

import { CrudPage } from "@/components/admin/crud/crud-page";
import { transactionSchema } from "@/lib/validations/form";

const columns = [
  { key: "orderId", label: "Order" },
  { key: "type", label: "Type" },
  { key: "status", label: "Status" },
  { key: "amount", label: "Amount" },
  { key: "paymentMethod", label: "Payment Method" },
  { key: "createdAt", label: "Created At" },
];

export default function TransactionsPage() {
  return (
    <CrudPage
      title="Transactions"
      columns={columns}
      schema={transactionSchema}
      endpoint="transactions"
      queryKey="transactions"
    />
  );
}
"use client";

import { CrudPage } from "@/components/admin/crud/crud-page";
import { categorySchema } from "@/lib/validations/form";

const columns = [
  { key: "name", label: "Name" },
  { key: "description", label: "Description" },
  { key: "levelId", label: "Level" },
];

export default function CategoriesPage() {
  return (
    <CrudPage
      title="Categories"
      columns={columns}
      schema={categorySchema}
      endpoint="categories"
      queryKey="categories"
    />
  );
}
**User:**

<task>
analyse this codebase 'app/' (see below for folder content) and fix the prisma crud on sections form data and table data
</task>

<folder_content path="app/">
├── admin/
├── api/
├── globals.css
├── layout.tsx
└── page.tsx

<file_content path="app/globals.css">
@tailwind base;
@tailwind components;
@tailwind utilities;

:root {
  --foreground-rgb: 0, 0, 0;
  --background-start-rgb: 214, 219, 220;
  --background-end-rgb: 255, 255, 255;
}

@media (prefers-color-scheme: dark) {
  :root {
    --foreground-rgb: 255, 255, 255;
    --background-start-rgb: 0, 0, 0;
    --background-end-rgb: 0, 0, 0;
  }
}

@layer base {
  :root {
    --background: 0 0% 100%;
    --foreground: 0 0% 3.9%;
    --card: 0 0% 100%;
    --card-foreground: 0 0% 3.9%;
    --popover: 0 0% 100%;
    --popover-foreground: 0 0% 3.9%;
    --primary: 0 0% 9%;
    --primary-foreground: 0 0% 98%;
    --secondary: 0 0% 96.1%;
    --secondary-foreground: 0 0% 9%;
    --muted: 0 0% 96.1%;
    --muted-foreground: 0 0% 45.1%;
    --accent: 0 0% 96.1%;
    --accent-foreground: 0 0% 9%;
    --destructive: 0 84.2% 60.2%;
    --destructive-foreground: 0 0% 98%;
    --border: 0 0% 89.8%;
    --input: 0 0% 89.8%;
    --ring: 0 0% 3.9%;
    --chart-1: 12 76% 61%;
    --chart-2: 173 58% 39%;
    --chart-3: 197 37% 24%;
    --chart-4: 43 74% 66%;
    --chart-5: 27 87% 67%;
    --radius: 0.5rem;
  }
  .dark {
    --background: 0 0% 3.9%;
    --foreground: 0 0% 98%;
    --card: 0 0% 3.9%;
    --card-foreground: 0 0% 98%;
    --popover: 0 0% 3.9%;
    --popover-foreground: 0 0% 98%;
    --primary: 0 0% 98%;
    --primary-foreground: 0 0% 9%;
    --secondary: 0 0% 14.9%;
    --secondary-foreground: 0 0% 98%;
    --muted: 0 0% 14.9%;
    --muted-foreground: 0 0% 63.9%;
    --accent: 0 0% 14.9%;
    --accent-foreground: 0 0% 98%;
    --destructive: 0 62.8% 30.6%;
    --destructive-foreground: 0 0% 98%;
    --border: 0 0% 14.9%;
    --input: 0 0% 14.9%;
    --ring: 0 0% 83.1%;
    --chart-1: 220 70% 50%;
    --chart-2: 160 60% 45%;
    --chart-3: 30 80% 55%;
    --chart-4: 280 65% 60%;
    --chart-5: 340 75% 55%;
  }
}

@layer base {
  * {
    @apply border-border;
  }
  body {
    @apply bg-background text-foreground;
  }
}

</file_content>

<file_content path="app/layout.tsx">
import './globals.css';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import { ThemeProvider } from '@/components/providers/theme-provider';
import { Toaster } from '@/components/ui/toaster';
import { Header } from '@/components/layout/header';
import { Footer } from '@/components/layout/footer';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'EduResource Hub - Premium Educational Materials',
  description: 'Access high-quality educational resources for all learning levels',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className} suppressHydrationWarning>
        <ThemeProvider
          attribute="class"
          defaultTheme="system"
          enableSystem
          disableTransitionOnChange
        >
          <div className="relative flex min-h-screen flex-col">
            <Header />
            <main className="flex-1">{children}</main>
            <Footer />
          </div>
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
</file_content>

<file_content path="app/page.tsx">
import { HeroSection } from "@/components/home/hero-section";
import { StatsSection } from "@/components/home/stats-section";
import { SubjectsSection } from "@/components/home/subjects-section";
import { FeaturesSection } from "@/components/home/features-section";
import { FeaturedResources } from "@/components/home/featured-resources";

export default function Home() {
  return (
    <div className="flex flex-col">
      <HeroSection />
      <StatsSection />
      <SubjectsSection />
      <FeaturesSection />
      <FeaturedResources />
    </div>
  );
}
</file_content>
</folder_content>
<environment_details>
# VSCode Visible Files
(No visible files)

# VSCode Open Tabs
(No open tabs)

# Current Working Directory (c:/Users/ITEC MARIUS/Desktop/test/project) Files
.env
.eslintrc.json
.gitignore
analysis.md
components.json
next.config.js
package-lock.json
package.json
postcss.config.js
tailwind.config.ts
tsconfig.json
app/
app/globals.css
app/layout.tsx
app/page.tsx
app/admin/
app/admin/layout.tsx
app/admin/page.tsx
app/admin/sections/
app/admin/sections/page.tsx
app/api/
app/api/sections/
app/api/sections/route.ts
components/
components/footer.tsx
components/header.tsx
components/theme-provider.tsx
components/admin/
components/admin/crud/
components/admin/crud/data-table.tsx
components/admin/crud/form-dialog.tsx
components/admin/dashboard/
components/admin/dashboard/dashboard-cards.tsx
components/admin/header/
components/admin/header/index.tsx
components/admin/header/search.tsx
components/admin/header/user-nav.tsx
components/admin/sidebar/
components/admin/sidebar/index.tsx
components/home/
components/home/feature-card.tsx
components/home/featured-resources.tsx
components/home/features-section.tsx
components/home/hero-section.tsx
components/home/resource-card.tsx
components/home/stats-section.tsx
components/home/subjects-section.tsx
components/layout/
components/layout/footer/
components/layout/footer/footer-brand.tsx
components/layout/footer/footer-section.tsx
components/layout/footer/index.tsx
components/layout/header/
components/layout/header/index.tsx
components/layout/header/logo.tsx
components/layout/header/nav-items.tsx
components/layout/header/theme-toggle.tsx
components/layout/header/user-nav.tsx
components/providers/
components/providers/admin-provider.tsx
components/providers/theme-provider.tsx
components/ui/
components/ui/accordion.tsx
components/ui/alert-dialog.tsx
components/ui/alert.tsx
components/ui/aspect-ratio.tsx
components/ui/avatar.tsx
components/ui/badge.tsx
components/ui/breadcrumb.tsx
components/ui/button.tsx
components/ui/calendar.tsx
components/ui/card.tsx
components/ui/carousel.tsx
components/ui/chart.tsx
components/ui/checkbox.tsx
components/ui/collapsible.tsx
components/ui/command.tsx
components/ui/context-menu.tsx
components/ui/dialog.tsx
components/ui/drawer.tsx
components/ui/dropdown-menu.tsx
components/ui/form.tsx
components/ui/hover-card.tsx
components/ui/input-otp.tsx
components/ui/input.tsx
components/ui/label.tsx
components/ui/menubar.tsx
components/ui/navigation-menu.tsx
components/ui/pagination.tsx
components/ui/popover.tsx
components/ui/progress.tsx
components/ui/radio-group.tsx
components/ui/resizable.tsx
components/ui/scroll-area.tsx
components/ui/select.tsx
components/ui/separator.tsx
components/ui/sheet.tsx
components/ui/skeleton.tsx
components/ui/slider.tsx
components/ui/sonner.tsx
components/ui/switch.tsx
components/ui/table.tsx
components/ui/tabs.tsx
components/ui/textarea.tsx
components/ui/toast.tsx
components/ui/toaster.tsx
components/ui/toggle-group.tsx
components/ui/toggle.tsx
components/ui/tooltip.tsx
hooks/
hooks/use-toast.ts
lib/
lib/prisma.ts
lib/utils.ts
lib/constants/
lib/constants/navigation.ts
lib/constants/resources.ts
lib/constants/subjects.ts
lib/types/
lib/types/resource.ts
lib/validations/
lib/validations/form.ts
prisma/
prisma/schema.prisma
prisma/seed.sql
prisma/migrations/
prisma/migrations/migration_lock.toml
prisma/migrations/20241220050457_revert_levels_to_required/
prisma/migrations/20241220050457_revert_levels_to_required/migration.sql
</environment_details>

---

**Assistant:**

<thinking>
Okay, I need to analyze the codebase and fix the Prisma CRUD operations related to sections form data and table data. Based on the file structure, I see relevant files in `app/api/sections/route.ts`, `components/admin/crud/data-table.tsx`, and `components/admin/crud/form-dialog.tsx`. I'll start by examining `app/api/sections/route.ts` to understand how the API endpoints are set up for handling section data. Then, I'll look at the `data-table.tsx` and `form-dialog.tsx` files to see how the data is being displayed and modified. I'll use `read_file` to inspect these files.
</thinking>
```tool_code
<read_file>
<path>app/api/sections/route.ts</path>
</read_file>
```

---

**User:**

[read_file for 'app/api/sections/route.ts'] Result:
import { NextResponse } from "next/server";
import { prisma } from "'lib/prisma"' (see below for file content);
import { sectionSchema } from "'lib/validations/form"' (see below for file content);
import { z, ZodError } from 'zod';

export async function GET() {
  try {
    const sections = await prisma.section.findMany({
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json(sections);
  } catch (error) {
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}

export async function POST(req: Request) {
  try {
    const body = await req.json();

    // Validate that the request payload is not empty
    if (Object.keys(body).length === 0) {
      return NextResponse.json(
        { error: "Request payload is empty" },
        { status: 400 }
      );
    }

    // Validate the request payload using the Zod schema
    const validatedData = sectionSchema.parse(body);

    const section = await prisma.section.create({
      data: validatedData,
    });

    return NextResponse.json(section);
  } catch (error) {
    if (error instanceof ZodError) {
      return NextResponse.json(
        { error: "Invalid request data", issues: error.errors },
        { status: 400 }
      );
    } else {
      return NextResponse.json(
        { error: "Internal Server Error" },
        { status: 500 }
      );
    }
  }
}

<file_content path="lib/prisma"">
Error fetching content: Failed to access path "lib/prisma"": ENOENT: no such file or directory, stat 'c:\Users\ITEC MARIUS\Desktop\test\project\lib\prisma"'
</file_content>

<file_content path="lib/validations/form"">
Error fetching content: Failed to access path "lib/validations/form"": ENOENT: no such file or directory, stat 'c:\Users\ITEC MARIUS\Desktop\test\project\lib\validations\form"'
</file_content>
<environment_details>
# VSCode Visible Files
(No visible files)

# VSCode Open Tabs
(No open tabs)
</environment_details>

---

**Assistant:**

<thinking>
It seems I made a mistake and the `read_file` tool failed to find the files `lib/prisma` and `lib/validations/form`. I should have included the file extensions. I'll try again with the correct file paths: `lib/prisma.ts` and `lib/validations/form.ts`. I'll also read the `prisma/schema.prisma` file to understand the database schema.
</thinking>
```tool_code
<read_file>
<path>lib/prisma.ts</path>
</read_file>
```

---

**User:**

[read_file for 'lib/prisma.ts'] Result:
import { PrismaClient } from "@prisma/client";

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: ["query"],
  });

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
<environment_details>
# VSCode Visible Files
(No visible files)

# VSCode Open Tabs
(No open tabs)
</environment_details>

---

**Assistant:**

```tool_code
<read_file>
<path>lib/validations/form.ts</path>
</read_file>
```

---

**User:**

[read_file for 'lib/validations/form.ts'] Result:
import { z } from "zod";

export const baseSchema = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().optional(),
});

export const sectionSchema = baseSchema;

export const levelSchema = baseSchema.extend({
  sectionId: z.string().min(1, "Section is required"),
});

export const categorySchema = baseSchema.extend({
  levelId: z.string().min(1, "Level is required"),
});

export const subjectSchema = baseSchema.extend({
  categoryId: z.string().min(1, "Category is required"),
});

export const materialSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  price: z.number().min(0, "Price must be positive"),
  subjectId: z.string().min(1, "Subject is required"),
  file: z.instanceof(File).optional(),
});
<environment_details>
# VSCode Visible Files
(No visible files)

# VSCode Open Tabs
(No open tabs)
</environment_details>

---

**Assistant:**

```tool_code
<read_file>
<path>prisma/schema.prisma</path>
</read_file>
```

---

**User:**

[read_file for 'prisma/schema.prisma'] Result:
// This is your Prisma schema file
datasource db {
  provider = "mysql"
  url      = env("DATABASE_URL")
}

generator client {
  provider = "prisma-client-js"
}

model Section {
  id          String    @id @default(cuid())
  name        String
  description String?
  createdAt   DateTime  @default(now())
  updatedAt   DateTime  @updatedAt
  levels      Level[]  // Make levels optional by adding a question mark
}

model Level {
  id          String    @id @default(cuid())
  name        String
  description String?
  section     Section   @relation(fields: [sectionId], references: [id])
  sectionId   String
  categories  Category[]
  createdAt   DateTime  @default(now())
  updatedAt   DateTime  @updatedAt
}

model Category {
  id          String    @id @default(cuid())
  name        String
  description String?
  level       Level     @relation(fields: [levelId], references: [id])
  levelId     String
  subjects    Subject[]
  createdAt   DateTime  @default(now())
  updatedAt   DateTime  @updatedAt
}

model Subject {
  id          String    @id @default(cuid())
  name        String
  description String?
  category    Category  @relation(fields: [categoryId], references: [id])
  categoryId  String
  materials   Material[]
  createdAt   DateTime  @default(now())
  updatedAt   DateTime  @updatedAt
}

model Material {
  id          String    @id @default(cuid())
  title       String
  description String?
  fileUrl     String
  price       Decimal
  subject     Subject   @relation(fields: [subjectId], references: [id])
  subjectId   String
  createdAt   DateTime  @default(now())
  updatedAt   DateTime  @updatedAt
}
<environment_details>
# VSCode Visible Files
(No visible files)

# VSCode Open Tabs
(No open tabs)
</environment_details>

---

**Assistant:**

<thinking>
Okay, I have now read the `lib/prisma.ts`, `lib/validations/form.ts`, and `prisma/schema.prisma` files.

Here's what I've gathered:

-   **`lib/prisma.ts`**: This file sets up the Prisma client for database interactions.
-   **`lib/validations/form.ts`**: This file defines Zod schemas for validating form data, including `sectionSchema`, which is just the `baseSchema` with `name` and `description`.
-   **`prisma/schema.prisma`**: This file defines the database schema, including the `Section` model, which has `id`, `name`, `description`, `createdAt`, `updatedAt`, and a relation to `Level`.

Now, I need to examine the `components/admin/crud/data-table.tsx` and `components/admin/crud/form-dialog.tsx` files to understand how the data is being displayed and modified.
</thinking>
```tool_code
<read_file>
<path>components/admin/crud/data-table.tsx</path>
</read_file>
```

---

**User:**

[read_file for 'components/admin/crud/data-table.tsx'] Result:
import { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "'components/ui/table"' (see below for file content);
import { Button } from "'components/ui/button"' (see below for file content);
import { Input } from "'components/ui/input"' (see below for file content);
import { useQuery } from "@tanstack/react-query";
import { Loader2, Search, Plus } from "lucide-react";
import { FormDialog } from "'components/admin/crud/form-dialog"' (see below for file content); // Adjust the path as necessary
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

const queryClient = new QueryClient();

export interface DataTableProps<T extends Record<string, any>> {
  columns: { key: string; label: string }[];
  queryKey: string;
  fetchFn: () => Promise<T[]>;
  onAdd: () => void;
  onEdit: (item: T) => void;
  onDelete: (item: T) => void;
  yourSchema: any;
  handleSubmit: (data: T) => Promise<void>; // Accepts the full structure of T
}

export function DataTable<T extends Record<string, any>>({
  columns,
  queryKey,
  fetchFn,
  onAdd,
  onEdit,
  onDelete,
  yourSchema,
  handleSubmit: onSubmit, // Rename during destructuring
}: DataTableProps<T>) {
  const [search, setSearch] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<T | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: [queryKey],
    queryFn: async () => {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE_URL}/api/sections`);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    },
  });

  const filteredData = data?.filter((item: any) =>
    Object.values(item).some(
      (value) =>
        typeof value === "string" &&
        value.toLowerCase().includes(search.toLowerCase())
    )
  );

  const handleEdit = (item: T) => {
    setDialogOpen(true);
    setSelectedItem(item);
  };

  const handleSubmit = async (data: any) => {
    if (selectedItem) {
      // Include the ID in the data being submitted
      data.id = selectedItem.id; // Assuming selectedItem contains the ID
    }

    console.log('Form submitted', data);
    // Add your submit logic here, e.g., API call to update the section
    try {
      const response = await fetch(`${process.env.NEXT_PUBLIC_API_BASE_URL}/api/sections/${data.id}`, {
        method: 'PUT', // or 'POST' depending on your logic
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        throw new Error('Failed to save section');
      }

      const result = await response.json();
      console.log('Section saved successfully:', result);
    } catch (error) {
      console.error('Error saving section:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center p-8">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Search className="h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-[300px]"
          />
        </div>
        <Button onClick={onAdd}>
          <Plus className="h-4 w-4 mr-2" />
          Add New
        </Button>
      </div>
      
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              {columns.map((column) => (
                <TableHead key={column.key}>{column.label}</TableHead>
              ))}
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredData?.map((item: T) => (
              <TableRow key={item.id}>
                {columns.map((column) => (
                  <TableCell key={column.key}>
                    {(item as any)[column.key]}
                  </TableCell>
                ))}
                <TableCell>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleEdit(item)}
                    >
                      Edit
                    </Button>
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => onDelete(item)}
                    >
                      Delete
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
      <FormDialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        title="Edit Section"
        schema={yourSchema}
        defaultValues={selectedItem}
        onSubmit={async (data: any) => {
          console.log('Form submitted', data);
          // Add your submit logic here, e.g., API call to update the section
          await handleSubmit(data);
        }}
        isSubmitting={isSubmitting}
      />
    </div>
  );
}

const DataTableComponent = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <DataTable />
    </QueryClientProvider>
  );
};

export default DataTableComponent;

<file_content path="components/ui/table"">
Error fetching content: Failed to access path "components/ui/table"": ENOENT: no such file or directory, stat 'c:\Users\ITEC MARIUS\Desktop\test\project\components\ui\table"'
</file_content>

<file_content path="components/ui/button"">
Error fetching content: Failed to access path "components/ui/button"": ENOENT: no such file or directory, stat 'c:\Users\ITEC MARIUS\Desktop\test\project\components\ui\button"'
</file_content>

<file_content path="components/ui/input"">
Error fetching content: Failed to access path "components/ui/input"": ENOENT: no such file or directory, stat 'c:\Users\ITEC MARIUS\Desktop\test\project\components\ui\input"'
</file_content>

<file_content path="components/admin/crud/form-dialog"">
Error fetching content: Failed to access path "components/admin/crud/form-dialog"": ENOENT: no such file or directory, stat 'c:\Users\ITEC MARIUS\Desktop\test\project\components\admin\crud\form-dialog"'
</file_content>
<environment_details>
# VSCode Visible Files
(No visible files)

# VSCode Open Tabs
(No open tabs)
</environment_details>


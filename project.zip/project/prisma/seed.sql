-- Seed Language Definitions
INSERT INTO languagedefinitions (code, name, nativeName, isActive) VALUES 
('EN', 'English', 'English', 1),
('FR', 'French', 'Français', 1),
('ES', 'Spanish', 'Español', 1);

-- Seed Currency Definitions
INSERT INTO currencydefinitions (code, name, symbol, exchangeRate, isDefault) VALUES 
('USD', 'US Dollar', '$', 1.0, 1),
('EUR', 'Euro', '€', 0.92, 0);

-- Seed Admin User (with bcrypt hashed password 'pass2024')
INSERT INTO users (email, password, role, name) VALUES 
('pass@edu.cm', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'ADMIN', 'PASS Admin');

-- Seed User Profile
INSERT INTO profiles (user_id, first_name, last_name) VALUES 
(1, 'PASS', 'Admin');

-- Seed Sections
INSERT INTO sections (id, name, description, createdAt, updatedAt) VALUES 
(1, 'Anglophone General', 'General education section for Anglophone students', '2024-12-08T11:56:50.298Z', '2024-12-08T11:56:50.298Z'),
(2, 'Anglophone Technical', 'Technical education section for Anglophone students', '2024-12-08T11:56:50.298Z', '2024-12-08T11:56:50.298Z'),
(3, 'Francophone', 'Education section for Francophone students', '2024-12-08T11:56:50.298Z', '2024-12-08T11:56:50.298Z'),
(4, 'University', 'Higher education section', '2024-12-08T11:56:50.298Z', '2024-12-08T11:56:50.298Z');

-- Seed Levels
INSERT INTO levels (id, name, description, sectionId, createdAt, updatedAt) VALUES 
(1, 'O Level', 'Ordinary Level Examination', 1, '2024-12-08T11:56:50.316Z', '2024-12-08T11:56:50.316Z'),
(2, 'A Level', 'Advanced Level Examination', 1, '2024-12-08T11:56:50.316Z', '2024-12-08T11:56:50.316Z'),
(3, 'Technical Intermediate', 'Intermediate Technical Level', 2, '2024-12-08T11:56:50.316Z', '2024-12-08T11:56:50.316Z'),
(4, 'Technical Advanced', 'Advanced Technical Level', 2, '2024-12-08T11:56:50.316Z', '2024-12-08T11:56:50.316Z');

-- Seed Level Translations
INSERT INTO leveltranslation (levelId, languageCode, name, description) VALUES 
(1, 'EN', 'O Level', 'Ordinary Level Examination'),
(1, 'FR', 'Niveau O', 'Examen de niveau ordinaire'),
(2, 'EN', 'A Level', 'Advanced Level Examination'),
(2, 'FR', 'Niveau A', 'Examen de niveau avancé');

-- Seed Categories
INSERT INTO categories (id, name, description, levelId, sectionId, createdAt, updatedAt) VALUES 
(1, 'SCIENCE', NULL, 1, 1, '2024-12-08T11:56:50.316Z', '2024-12-08T11:56:50.316Z'),
(2, 'ARTS', NULL, 1, 1, '2024-12-08T11:56:50.316Z', '2024-12-08T11:56:50.316Z'),
(3, 'SCIENCE', NULL, 2, 1, '2024-12-08T11:56:50.316Z', '2024-12-08T11:56:50.316Z'),
(4, 'ARTS', NULL, 2, 1, '2024-12-08T11:56:50.316Z', '2024-12-08T11:56:50.316Z');
